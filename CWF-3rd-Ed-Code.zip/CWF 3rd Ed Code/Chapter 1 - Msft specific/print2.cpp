// If you're using Microsoft V.S. leave in this line:
#include "stdafx.h"

#include <iostream>
using namespace std;

int _tmain() 
{
     cout << "I am Blaxxon," << endl;
     cout << "the godlike computer." << endl;
     cout << "Fear me!" << endl;
     return 0;
}

