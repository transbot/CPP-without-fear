#include <iostream>
using namespace std;

int main()
{
     cout << "I am Blaxxon," << endl;
     cout << "the godlike computer." << endl;
     cout << "Fear me!" << endl;
     return 0;
}

